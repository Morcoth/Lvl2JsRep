function message(text) {
    console.log('Вызван метод message; text = ', text);
}

message('Первый вызов message');
message('Второй вызов message');
message('Третий вызов message');

alert('Works!');